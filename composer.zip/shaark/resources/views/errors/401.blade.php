@extends('error')

@section('title', __('Unauthorized'))
@section('code', '401')
@section('message', __('Sorry, the page you are looking for could not be found.'))
