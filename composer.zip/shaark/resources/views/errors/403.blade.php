@extends('error')

@section('title', __('Forbidden'))
@section('code', '403')
@section('message', __('Sorry, you are forbidden from accessing this page.'))
