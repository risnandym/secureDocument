@extends('layouts.manage')

@section('content')
<div class="row justify-content-center">
    <div class="col-12">
        <users></users>
    </div>
</div>
@endsection
