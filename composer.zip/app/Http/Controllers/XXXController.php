<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class XXXController extends Controller
{
    public function hasils(){
        return view('results');
    }
}
