<!--  -->

<?php $__env->startSection('main-content'); ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Dashboard')); ?></h1>

    <?php if(session('success')): ?>
    <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-end">
          <a class="page-link" href="<?php echo e(url('/file-upload')); ?>">+ Ajukan dokumen baru</a>
        </li>
      </ul>
    </nav>
    <!-- <img src="data:image/png;base64, <?php echo base64_encode(QrCode::format('png')->size(100)->generate($rd_string=Str::random(100))); ?> ">
   <?php echo e(QrCode::generate($rd_string=Str::random(150))); ?> -->
        
    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Document</th>
            <th scope="col">View</th>
            <!-- <th scope="col">Handle</th> -->
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($f->file_path); ?></td> 
            <td><?php echo e($f->name); ?></td>

             <td><a href="<?php echo e(Storage::url($f->name)); ?>">Klik</a>
               </td>
               <!-- <td><form action="/file-delete" method="post">
               <?php echo method_field('delete'); ?>

               <button type="submit">Delete</button>
               </form></td> -->
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </tbody>
    </table>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Tugas Akhir\System\sbadmin\resources\views/home.blade.php ENDPATH**/ ?>